#include <stdio.h>
#include <string.h>

#define MAX_LEN 100
#define MAX_SCORE 100

int main() {
    // Variable declarations
    char studentName[MAX_LEN];   // Character array for name
    char course[MAX_LEN];   // Character array for course
    int score1, score2, score3;   // Whole numbers - test scores
    int totalScore;   // Whole number - sum of scores
    double average;   // Decimal number - average
    double percentage;   // Decimal number - percentage

    // Welcome banner
    printf("========================================\n");
    printf(" STUDENT SCORE CALCULATOR\n");
    printf("========================================\n\n");

    // Input: student name
    printf("Enter student name: ");
    fgets(studentName, MAX_LEN, stdin);
    studentName[strcspn(studentName, "\n")] = '\0';

    // Input: course
    printf("Enter course (BBIT/BCS): ");
    fgets(course, MAX_LEN, stdin);
    course[strcspn(course, "\n")] = '\0';

    // Input: test scores
    printf("Enter score for Test 1: ");
    scanf("%d", &score1);
    printf("Enter score for Test 2: ");
    scanf("%d", &score2);
    printf("Enter score for Test 3: ");
    scanf("%d", &score3);

    // Calculations
    totalScore = score1 + score2 + score3;   // Add scores
    average = totalScore / 3.0;   // Decimal division
    percentage = (totalScore / 300.0) * 100;   // Percentage

    // Output: report card
    printf("\n");
    printf("========================================\n");
    printf(" REPORT CARD\n");
    printf("========================================\n\n");
    printf("Student: %s\n", studentName);
    printf("Course: %s\n", course);
    printf("\n");
    printf("Test 1: %d/%d\n", score1, MAX_SCORE);
    printf("Test 2: %d/%d\n", score2, MAX_SCORE);
    printf("Test 3: %d/%d\n", score3, MAX_SCORE);
    printf("\n");
    printf("Total: %d/300\n", totalScore);
    printf("Average: %.2f\n", average);
    printf("Percentage: %.2f%%\n", percentage);
    printf("\n");
    if (percentage >= 50) {
        printf("Result: PASS\n");
    } else {
        printf("Result: FAIL\n");
    }
    printf("========================================\n");

    return 0;
}

//gcc score_calculator.c -o score_calculator
//./score_calculator