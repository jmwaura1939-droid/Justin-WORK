#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main() {
    // Variable declarations
    string studentName;   // Text - stores the student's name
    string course;   // Text - stores the course (BBIT/BCS)
    int score1, score2, score3;   // Whole numbers - test scores
    int totalScore;   // Whole number - sum of scores
    double average;   // Decimal number - average score
    double percentage;   // Decimal number - percentage

    // Constant declaration
    const int MAX_SCORE = 100;   // Maximum possible score per test

    // Welcome banner
    cout << "========================================" << endl;
    cout << " STUDENT SCORE CALCULATOR" << endl;
    cout << "========================================" << endl;
    cout << endl;

    // Input: student name
    cout << "Enter student name: ";
    getline(cin, studentName);

    // Input: course
    cout << "Enter course (BBIT/BCS): ";
    getline(cin, course);

    // Input: test scores
    cout << "Enter score for Test 1: ";
    cin >> score1;
    cout << "Enter score for Test 2: ";
    cin >> score2;
    cout << "Enter score for Test 3: ";
    cin >> score3;

    // Calculations
    totalScore = score1 + score2 + score3;   // Add scores
    average = totalScore / 3.0;   // Decimal division
    percentage = (totalScore / 300.0) * 100;   // Percentage

    // Output: report card
    cout << endl;
    cout << "========================================" << endl;
    cout << " REPORT CARD" << endl;
    cout << "========================================" << endl;
    cout << endl;
    cout << "Student: " << studentName << endl;
    cout << "Course: " << course << endl;
    cout << endl;
    cout << "Test 1: " << score1 << "/" << MAX_SCORE << endl;
    cout << "Test 2: " << score2 << "/" << MAX_SCORE << endl;
    cout << "Test 3: " << score3 << "/" << MAX_SCORE << endl;
    cout << endl;
    cout << "Total: " << totalScore << "/300" << endl;
    cout << "Average: " << fixed << setprecision(2) << average << endl;
    cout << "Percentage: " << fixed << setprecision(2) << percentage << "%" << endl;
    cout << endl;
    if (percentage >= 50) {
        cout << "Result: PASS" << endl;
    } else {
        cout << "Result: FAIL" << endl;
    }
    cout << "========================================" << endl;

    return 0;
}

//g++ score_calculator.cpp -o score_calculator
//./score_calculator